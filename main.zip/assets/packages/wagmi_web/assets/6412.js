"use strict";(self.webpackChunk=self.webpackChunk||[]).push([[6412],{36412:(t,e,r)=>{r.r(e),r.d(e,{PhCaretUp:()=>c}),r(94687);var l=r(76058),a=r(15375),i=r(3588),o=r(31409),s=r(11893),p=Object.defineProperty,h=Object.getOwnPropertyDescriptor,n=(t,e,r,l)=>{for(var a,i=l>1?void 0:l?h(e,r):e,o=t.length-1;o>=0;o--)(a=t[o])&&(i=(l?a(e,r,i):a(i))||i);return l&&i&&p(e,r,i),i};let c=class extends a.WF{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return l.qy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",l.JW`<path d="M210.83,162.83a4,4,0,0,1-5.66,0L128,85.66,50.83,162.83a4,4,0,0,1-5.66-5.66l80-80a4,4,0,0,1,5.66,0l80,80A4,4,0,0,1,210.83,162.83Z"/>`],["light",l.JW`<path d="M212.24,164.24a6,6,0,0,1-8.48,0L128,88.49,52.24,164.24a6,6,0,0,1-8.48-8.48l80-80a6,6,0,0,1,8.48,0l80,80A6,6,0,0,1,212.24,164.24Z"/>`],["regular",l.JW`<path d="M213.66,165.66a8,8,0,0,1-11.32,0L128,91.31,53.66,165.66a8,8,0,0,1-11.32-11.32l80-80a8,8,0,0,1,11.32,0l80,80A8,8,0,0,1,213.66,165.66Z"/>`],["bold",l.JW`<path d="M216.49,168.49a12,12,0,0,1-17,0L128,97,56.49,168.49a12,12,0,0,1-17-17l80-80a12,12,0,0,1,17,0l80,80A12,12,0,0,1,216.49,168.49Z"/>`],["fill",l.JW`<path d="M215.39,163.06A8,8,0,0,1,208,168H48a8,8,0,0,1-5.66-13.66l80-80a8,8,0,0,1,11.32,0l80,80A8,8,0,0,1,215.39,163.06Z"/>`],["duotone",l.JW`<path d="M208,160H48l80-80Z" opacity="0.2"/><path d="M213.66,154.34l-80-80a8,8,0,0,0-11.32,0l-80,80A8,8,0,0,0,48,168H208a8,8,0,0,0,5.66-13.66ZM67.31,152,128,91.31,188.69,152Z"/>`]]),c.styles=s.AH`
    :host {
      display: contents;
    }
  `,n([(0,o.M)({type:String,reflect:!0})],c.prototype,"size",2),n([(0,o.M)({type:String,reflect:!0})],c.prototype,"weight",2),n([(0,o.M)({type:String,reflect:!0})],c.prototype,"color",2),n([(0,o.M)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=n([(0,i.E)("ph-caret-up")],c)}}]);
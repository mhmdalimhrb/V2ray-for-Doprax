"use strict";(self.webpackChunk=self.webpackChunk||[]).push([[1634],{1634:(t,e,r)=>{r.r(e),r.d(e,{PhPlus:()=>c}),r(94687);var a=r(76058),h=r(15375),s=r(3588),i=r(31409),o=r(11893),p=Object.defineProperty,l=Object.getOwnPropertyDescriptor,n=(t,e,r,a)=>{for(var h,s=a>1?void 0:a?l(e,r):e,i=t.length-1;i>=0;i--)(h=t[i])&&(s=(a?h(e,r,s):h(s))||s);return a&&s&&p(e,r,s),s};let c=class extends h.WF{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return a.qy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",a.JW`<path d="M220,128a4,4,0,0,1-4,4H132v84a4,4,0,0,1-8,0V132H40a4,4,0,0,1,0-8h84V40a4,4,0,0,1,8,0v84h84A4,4,0,0,1,220,128Z"/>`],["light",a.JW`<path d="M222,128a6,6,0,0,1-6,6H134v82a6,6,0,0,1-12,0V134H40a6,6,0,0,1,0-12h82V40a6,6,0,0,1,12,0v82h82A6,6,0,0,1,222,128Z"/>`],["regular",a.JW`<path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/>`],["bold",a.JW`<path d="M228,128a12,12,0,0,1-12,12H140v76a12,12,0,0,1-24,0V140H40a12,12,0,0,1,0-24h76V40a12,12,0,0,1,24,0v76h76A12,12,0,0,1,228,128Z"/>`],["fill",a.JW`<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM184,136H136v48a8,8,0,0,1-16,0V136H72a8,8,0,0,1,0-16h48V72a8,8,0,0,1,16,0v48h48a8,8,0,0,1,0,16Z"/>`],["duotone",a.JW`<path d="M216,56V200a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V56A16,16,0,0,1,56,40H200A16,16,0,0,1,216,56Z" opacity="0.2"/><path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/>`]]),c.styles=o.AH`
    :host {
      display: contents;
    }
  `,n([(0,i.M)({type:String,reflect:!0})],c.prototype,"size",2),n([(0,i.M)({type:String,reflect:!0})],c.prototype,"weight",2),n([(0,i.M)({type:String,reflect:!0})],c.prototype,"color",2),n([(0,i.M)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=n([(0,s.E)("ph-plus")],c)}}]);
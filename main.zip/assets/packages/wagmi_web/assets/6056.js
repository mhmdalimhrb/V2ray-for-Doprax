"use strict";(self.webpackChunk=self.webpackChunk||[]).push([[6056],{7068:(e,t,a)=>{var n=a(12618),i=a(25707),r=(a(14991),a(26109)),o=a(43494);const s=a(67569).AH`
  button {
    background-color: transparent;
    padding: ${({spacing:e})=>e[1]};
  }

  button:focus-visible {
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent020};
  }

  button[data-variant='accent']:hover:enabled,
  button[data-variant='accent']:focus-visible {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button[data-variant='primary']:hover:enabled,
  button[data-variant='primary']:focus-visible,
  button[data-variant='secondary']:hover:enabled,
  button[data-variant='secondary']:focus-visible {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button[data-size='xs'] > wui-icon {
    width: 8px;
    height: 8px;
  }

  button[data-size='sm'] > wui-icon {
    width: 12px;
    height: 12px;
  }

  button[data-size='xs'],
  button[data-size='sm'] {
    border-radius: ${({borderRadius:e})=>e[1]};
  }

  button[data-size='md'],
  button[data-size='lg'] {
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  button[data-size='md'] > wui-icon {
    width: 16px;
    height: 16px;
  }

  button[data-size='lg'] > wui-icon {
    width: 20px;
    height: 20px;
  }

  button:disabled {
    background-color: transparent;
    cursor: not-allowed;
    opacity: 0.5;
  }

  button:hover:not(:disabled) {
    background-color: var(--wui-color-accent-glass-015);
  }

  button:focus-visible:not(:disabled) {
    background-color: var(--wui-color-accent-glass-015);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0 0 0 4px var(--wui-color-accent-glass-020);
  }
`;var c=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let d=class extends n.WF{constructor(){super(...arguments),this.size="md",this.disabled=!1,this.icon="copy",this.iconColor="default",this.variant="accent"}render(){return n.qy`
      <button data-variant=${this.variant} ?disabled=${this.disabled} data-size=${this.size}>
        <wui-icon
          color=${{accent:"accent-primary",primary:"inverse",secondary:"default"}[this.variant]||this.iconColor}
          size=${this.size}
          name=${this.icon}
        ></wui-icon>
      </button>
    `}};d.styles=[r.W5,r.fD,s],c([(0,i.MZ)()],d.prototype,"size",void 0),c([(0,i.MZ)({type:Boolean})],d.prototype,"disabled",void 0),c([(0,i.MZ)()],d.prototype,"icon",void 0),c([(0,i.MZ)()],d.prototype,"iconColor",void 0),c([(0,i.MZ)()],d.prototype,"variant",void 0),d=c([(0,o.E)("wui-icon-link")],d)},26509:(e,t,a)=>{var n=a(12618),i=a(25707),r=a(60031),o=(a(20880),a(18409),a(26109)),s=a(43494);const c=a(67569).AH`
  :host {
    width: 100%;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      scale ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, scale;
  }

  wui-text {
    text-transform: capitalize;
  }

  wui-image {
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var d=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let l=class extends n.WF{constructor(){super(...arguments),this.imageSrc="google",this.loading=!1,this.disabled=!1,this.rightIcon=!0,this.rounded=!1,this.fullSize=!1}render(){return this.dataset.rounded=this.rounded?"true":"false",n.qy`
      <button
        ?disabled=${!!this.loading||Boolean(this.disabled)}
        data-loading=${this.loading}
        tabindex=${(0,r.J)(this.tabIdx)}
      >
        <wui-flex gap="2" alignItems="center">
          ${this.templateLeftIcon()}
          <wui-flex gap="1">
            <slot></slot>
          </wui-flex>
        </wui-flex>
        ${this.templateRightIcon()}
      </button>
    `}templateLeftIcon(){return this.icon?n.qy`<wui-image
        icon=${this.icon}
        iconColor=${(0,r.J)(this.iconColor)}
        ?boxed=${!0}
        ?rounded=${this.rounded}
      ></wui-image>`:n.qy`<wui-image
      ?boxed=${!0}
      ?rounded=${this.rounded}
      ?fullSize=${this.fullSize}
      src=${this.imageSrc}
    ></wui-image>`}templateRightIcon(){return this.rightIcon?this.loading?n.qy`<wui-loading-spinner size="md" color="accent-primary"></wui-loading-spinner>`:n.qy`<wui-icon name="chevronRight" size="lg" color="default"></wui-icon>`:null}};l.styles=[o.W5,o.fD,c],d([(0,i.MZ)()],l.prototype,"imageSrc",void 0),d([(0,i.MZ)()],l.prototype,"icon",void 0),d([(0,i.MZ)()],l.prototype,"iconColor",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"loading",void 0),d([(0,i.MZ)()],l.prototype,"tabIdx",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"disabled",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"rightIcon",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"rounded",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"fullSize",void 0),l=d([(0,s.E)("wui-list-item")],l)},27512:(e,t,a)=>{a.d(t,{a:()=>n});const n=a(12618).JW`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`},28788:(e,t,a)=>{var n=a(12618),i=a(25707);const r=n.JW`<svg width="86" height="96" fill="none">
  <path
    d="M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z"
  />
</svg>`;var o=a(27512);const s=n.JW`
  <svg fill="none" viewBox="0 0 36 40">
    <path
      d="M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z"
    />
  </svg>
`;a(14991),a(36887);var c=a(26109),d=a(43494);const l=a(67569).AH`
  :host {
    position: relative;
    border-radius: inherit;
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--local-width);
    height: var(--local-height);
  }

  :host([data-round='true']) {
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: 100%;
    outline: 1px solid ${({tokens:e})=>e.core.glass010};
  }

  svg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
  }

  svg > path {
    stroke: var(--local-stroke);
  }

  wui-image {
    width: 100%;
    height: 100%;
    -webkit-clip-path: var(--local-path);
    clip-path: var(--local-path);
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  wui-icon {
    transform: translateY(-5%);
    width: var(--local-icon-size);
    height: var(--local-icon-size);
  }
`;var u=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let p=class extends n.WF{constructor(){super(...arguments),this.size="md",this.name="uknown",this.networkImagesBySize={sm:s,md:o.a,lg:r},this.selected=!1,this.round=!1}render(){return this.round?(this.dataset.round="true",this.style.cssText="\n      --local-width: var(--apkt-spacing-10);\n      --local-height: var(--apkt-spacing-10);\n      --local-icon-size: var(--apkt-spacing-4);\n    "):this.style.cssText=`\n\n      --local-path: var(--apkt-path-network-${this.size});\n      --local-width:  var(--apkt-width-network-${this.size});\n      --local-height:  var(--apkt-height-network-${this.size});\n      --local-icon-size:  var(--apkt-spacing-${{sm:"4",md:"6",lg:"10"}[this.size]});\n    `,n.qy`${this.templateVisual()} ${this.svgTemplate()} `}svgTemplate(){return this.round?null:this.networkImagesBySize[this.size]}templateVisual(){return this.imageSrc?n.qy`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:n.qy`<wui-icon size="inherit" color="default" name="networkPlaceholder"></wui-icon>`}};p.styles=[c.W5,l],u([(0,i.MZ)()],p.prototype,"size",void 0),u([(0,i.MZ)()],p.prototype,"name",void 0),u([(0,i.MZ)({type:Object})],p.prototype,"networkImagesBySize",void 0),u([(0,i.MZ)()],p.prototype,"imageSrc",void 0),u([(0,i.MZ)({type:Boolean})],p.prototype,"selected",void 0),u([(0,i.MZ)({type:Boolean})],p.prototype,"round",void 0),p=u([(0,d.E)("wui-network-image")],p)},41684:(e,t,a)=>{a(91383)},55618:(e,t,a)=>{var n=a(12618),i=a(25707),r=(a(18409),a(26109)),o=a(43494);const s=a(67569).AH`
  :host {
    position: relative;
    display: flex;
    width: 100%;
    height: 1px;
    background-color: ${({tokens:e})=>e.theme.borderPrimary};
    justify-content: center;
    align-items: center;
  }

  :host > wui-text {
    position: absolute;
    padding: 0px 8px;
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }
`;var c=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let d=class extends n.WF{constructor(){super(...arguments),this.text=""}render(){return n.qy`${this.template()}`}template(){return this.text?n.qy`<wui-text variant="md-regular" color="secondary">${this.text}</wui-text>`:null}};d.styles=[r.W5,s],c([(0,i.MZ)()],d.prototype,"text",void 0),d=c([(0,o.E)("wui-separator")],d)},64865:(e,t,a)=>{a(7068)},83675:(e,t,a)=>{a.r(t),a.d(t,{W3mPayLoadingView:()=>G,W3mPayView:()=>U,arbitrumUSDC:()=>te,arbitrumUSDT:()=>oe,baseETH:()=>K,baseSepoliaETH:()=>X,baseUSDC:()=>J,ethereumUSDC:()=>Q,ethereumUSDT:()=>ie,getExchanges:()=>q,getIsPaymentInProgress:()=>H,getPayError:()=>j,getPayResult:()=>F,openPay:()=>Y,optimismUSDC:()=>ee,optimismUSDT:()=>re,pay:()=>V,polygonUSDC:()=>ae,polygonUSDT:()=>se,solanaSOL:()=>de,solanaUSDC:()=>ne,solanaUSDT:()=>ce});var n=a(12618),i=a(25707),r=a(60031),o=a(6056),s=a(96396),c=a(26742),d=a(21871),l=a(79177),u=a(70148),p=(a(58461),a(60310),a(51636),a(84293),a(64865),a(93516),a(26509),a(93373),a(28788),a(55618),a(45090),a(41684),a(68126)),h=a(4707),m=a(24376),y=a(75910),g=a(90184),w=a(70424),f=a(78508);const b={INVALID_PAYMENT_CONFIG:"INVALID_PAYMENT_CONFIG",INVALID_RECIPIENT:"INVALID_RECIPIENT",INVALID_ASSET:"INVALID_ASSET",INVALID_AMOUNT:"INVALID_AMOUNT",UNKNOWN_ERROR:"UNKNOWN_ERROR",UNABLE_TO_INITIATE_PAYMENT:"UNABLE_TO_INITIATE_PAYMENT",INVALID_CHAIN_NAMESPACE:"INVALID_CHAIN_NAMESPACE",GENERIC_PAYMENT_ERROR:"GENERIC_PAYMENT_ERROR",UNABLE_TO_GET_EXCHANGES:"UNABLE_TO_GET_EXCHANGES",ASSET_NOT_SUPPORTED:"ASSET_NOT_SUPPORTED",UNABLE_TO_GET_PAY_URL:"UNABLE_TO_GET_PAY_URL",UNABLE_TO_GET_BUY_STATUS:"UNABLE_TO_GET_BUY_STATUS"},v={[b.INVALID_PAYMENT_CONFIG]:"Invalid payment configuration",[b.INVALID_RECIPIENT]:"Invalid recipient address",[b.INVALID_ASSET]:"Invalid asset specified",[b.INVALID_AMOUNT]:"Invalid payment amount",[b.UNKNOWN_ERROR]:"Unknown payment error occurred",[b.UNABLE_TO_INITIATE_PAYMENT]:"Unable to initiate payment",[b.INVALID_CHAIN_NAMESPACE]:"Invalid chain namespace",[b.GENERIC_PAYMENT_ERROR]:"Unable to process payment",[b.UNABLE_TO_GET_EXCHANGES]:"Unable to get exchanges",[b.ASSET_NOT_SUPPORTED]:"Asset not supported by the selected exchange",[b.UNABLE_TO_GET_PAY_URL]:"Unable to get payment URL",[b.UNABLE_TO_GET_BUY_STATUS]:"Unable to get buy status"};class E extends Error{get message(){return v[this.code]}constructor(e,t){super(v[e]),this.name="AppKitPayError",this.code=e,this.details=t,Error.captureStackTrace&&Error.captureStackTrace(this,E)}}var x=a(57019);class I extends Error{}async function A(e,t){const a=`https://rpc.walletconnect.org/v1/json-rpc?projectId=${x.H.getSnapshot().projectId}`,{sdkType:n,sdkVersion:i,projectId:r}=x.H.getSnapshot(),o={jsonrpc:"2.0",id:1,method:e,params:{...t||{},st:n,sv:i,projectId:r}},s=await fetch(a,{method:"POST",body:JSON.stringify(o),headers:{"Content-Type":"application/json"}}),c=await s.json();if(c.error)throw new I(c.error.message);return c}async function N(e){return(await A("reown_getExchanges",e)).result}const P=["eip155","solana"],k={eip155:{native:{assetNamespace:"slip44",assetReference:"60"},defaultTokenNamespace:"erc20"},solana:{native:{assetNamespace:"slip44",assetReference:"501"},defaultTokenNamespace:"token"}};function S(e,t){const{chainNamespace:a,chainId:n}=y.C.parseCaipNetworkId(e),i=k[a];if(!i)throw new Error(`Unsupported chain namespace for CAIP-19 formatting: ${a}`);let r=i.native.assetNamespace,o=i.native.assetReference;return"native"!==t&&(r=i.defaultTokenNamespace,o=t),`${a}:${n}/${r}:${o}`}var C=a(36210);const T="unknown",_=(0,p.BX)({paymentAsset:{network:"eip155:1",asset:"0x0",metadata:{name:"0x0",symbol:"0x0",decimals:0}},recipient:"0x0",amount:0,isConfigured:!1,error:null,isPaymentInProgress:!1,exchanges:[],isLoading:!1,openInNewTab:!0,redirectUrl:void 0,payWithExchange:void 0,currentPayment:void 0,analyticsSet:!1,paymentId:void 0}),R={state:_,subscribe:e=>(0,p.B1)(_,()=>e(_)),subscribeKey:(e,t)=>(0,h.u$)(_,e,t),async handleOpenPay(e){this.resetState(),this.setPaymentConfig(e),this.subscribeEvents(),this.initializeAnalytics(),_.isConfigured=!0,g.E.sendEvent({type:"track",event:"PAY_MODAL_OPEN",properties:{exchanges:_.exchanges,configuration:{network:_.paymentAsset.network,asset:_.paymentAsset.asset,recipient:_.recipient,amount:_.amount}}}),await s.W.open({view:"Pay"})},resetState(){_.paymentAsset={network:"eip155:1",asset:"0x0",metadata:{name:"0x0",symbol:"0x0",decimals:0}},_.recipient="0x0",_.amount=0,_.isConfigured=!1,_.error=null,_.isPaymentInProgress=!1,_.isLoading=!1,_.currentPayment=void 0},setPaymentConfig(e){if(!e.paymentAsset)throw new E(b.INVALID_PAYMENT_CONFIG);try{_.paymentAsset=e.paymentAsset,_.recipient=e.recipient,_.amount=e.amount,_.openInNewTab=e.openInNewTab??!0,_.redirectUrl=e.redirectUrl,_.payWithExchange=e.payWithExchange,_.error=null}catch(e){throw new E(b.INVALID_PAYMENT_CONFIG,e.message)}},getPaymentAsset:()=>_.paymentAsset,getExchanges:()=>_.exchanges,async fetchExchanges(){try{_.isLoading=!0;const e=await N({page:0,asset:S(_.paymentAsset.network,_.paymentAsset.asset),amount:_.amount.toString()});_.exchanges=e.exchanges.slice(0,2)}catch(e){throw d.P.showError(v.UNABLE_TO_GET_EXCHANGES),new E(b.UNABLE_TO_GET_EXCHANGES)}finally{_.isLoading=!1}},async getAvailableExchanges(e){try{const t=e?.asset&&e?.network?S(e.network,e.asset):void 0;return await N({page:e?.page??0,asset:t,amount:e?.amount?.toString()})}catch(e){throw new E(b.UNABLE_TO_GET_EXCHANGES)}},async getPayUrl(e,t,a=!1){try{const n=Number(t.amount),i=await async function(e){return(await A("reown_getExchangePayUrl",e)).result}({exchangeId:e,asset:S(t.network,t.asset),amount:n.toString(),recipient:`${t.network}:${t.recipient}`});return g.E.sendEvent({type:"track",event:"PAY_EXCHANGE_SELECTED",properties:{source:"pay",exchange:{id:e},configuration:{network:t.network,asset:t.asset,recipient:t.recipient,amount:n},currentPayment:{type:"exchange",exchangeId:e},headless:a}}),a&&(this.initiatePayment(),g.E.sendEvent({type:"track",event:"PAY_INITIATED",properties:{source:"pay",paymentId:_.paymentId||T,configuration:{network:t.network,asset:t.asset,recipient:t.recipient,amount:n},currentPayment:{type:"exchange",exchangeId:e}}})),i}catch(e){if(e instanceof Error&&e.message.includes("is not supported"))throw new E(b.ASSET_NOT_SUPPORTED);throw new Error(e.message)}},async openPayUrl(e,t,a=!1){try{const n=await this.getPayUrl(e.exchangeId,t,a);if(!n)throw new E(b.UNABLE_TO_GET_PAY_URL);const i=e.openInNewTab??1?"_blank":"_self";return c.w.openHref(n.url,i),n}catch(e){throw _.error=e instanceof E?e.message:v.GENERIC_PAYMENT_ERROR,new E(b.UNABLE_TO_GET_PAY_URL)}},subscribeEvents(){_.isConfigured||(l.x.subscribeKey("connections",e=>{e.size>0&&this.handlePayment()}),o.W.subscribeChainProp("accountState",e=>{const t=l.x.hasAnyConnection(m.o.CONNECTOR_ID.WALLET_CONNECT);e?.caipAddress&&(t?setTimeout(()=>{this.handlePayment()},100):this.handlePayment())}))},async handlePayment(){_.currentPayment={type:"wallet",status:"IN_PROGRESS"};const e=o.W.getActiveCaipAddress();if(!e)return;const{chainId:t,address:a}=y.C.parseCaipAddress(e),n=o.W.state.activeChain;if(!a||!t||!n)return;if(!w.G.getProvider(n))return;const i=o.W.state.activeCaipNetwork;if(i&&!_.isPaymentInProgress)try{this.initiatePayment();const e=o.W.getAllRequestedCaipNetworks(),t=o.W.getAllApprovedCaipNetworkIds();switch(await async function(e){const{paymentAssetNetwork:t,activeCaipNetwork:a,approvedCaipNetworkIds:n,requestedCaipNetworks:i}=e,r=c.w.sortRequestedNetworks(n,i).find(e=>e.caipNetworkId===t);if(!r)throw new E(b.INVALID_PAYMENT_CONFIG);if(r.caipNetworkId===a.caipNetworkId)return;const s=o.W.getNetworkProp("supportsAllNetworks",r.chainNamespace);if(!n?.includes(r.caipNetworkId)&&!s)throw new E(b.INVALID_PAYMENT_CONFIG);try{await o.W.switchActiveNetwork(r)}catch(e){throw new E(b.GENERIC_PAYMENT_ERROR,e)}}({paymentAssetNetwork:_.paymentAsset.network,activeCaipNetwork:i,approvedCaipNetworkIds:t,requestedCaipNetworks:e}),await s.W.open({view:"PayLoading"}),n){case m.o.CHAIN.EVM:"native"===_.paymentAsset.asset&&(_.currentPayment.result=await async function(e,t,a){if(t!==m.o.CHAIN.EVM)throw new E(b.INVALID_CHAIN_NAMESPACE);if(!a.fromAddress)throw new E(b.INVALID_PAYMENT_CONFIG,"fromAddress is required for native EVM payments.");const n="string"==typeof a.amount?parseFloat(a.amount):a.amount;if(isNaN(n))throw new E(b.INVALID_PAYMENT_CONFIG);const i=e.metadata?.decimals??18,r=l.x.parseUnits(n.toString(),i);if("bigint"!=typeof r)throw new E(b.GENERIC_PAYMENT_ERROR);return await l.x.sendTransaction({chainNamespace:t,to:a.recipient,address:a.fromAddress,value:r,data:"0x"})??void 0}(_.paymentAsset,n,{recipient:_.recipient,amount:_.amount,fromAddress:a})),_.paymentAsset.asset.startsWith("0x")&&(_.currentPayment.result=await async function(e,t){if(!t.fromAddress)throw new E(b.INVALID_PAYMENT_CONFIG,"fromAddress is required for ERC20 EVM payments.");const a=e.asset,n=t.recipient,i=Number(e.metadata.decimals),r=l.x.parseUnits(t.amount.toString(),i);if(void 0===r)throw new E(b.GENERIC_PAYMENT_ERROR);return await l.x.writeContract({fromAddress:t.fromAddress,tokenAddress:a,args:[n,r],method:"transfer",abi:C.v.getERC20Abi(a),chainNamespace:m.o.CHAIN.EVM})??void 0}(_.paymentAsset,{recipient:_.recipient,amount:_.amount,fromAddress:a})),_.currentPayment.status="SUCCESS";break;case m.o.CHAIN.SOLANA:_.currentPayment.result=await async function(e,t){if(e!==m.o.CHAIN.SOLANA)throw new E(b.INVALID_CHAIN_NAMESPACE);if(!t.fromAddress)throw new E(b.INVALID_PAYMENT_CONFIG,"fromAddress is required for Solana payments.");const a="string"==typeof t.amount?parseFloat(t.amount):t.amount;if(isNaN(a)||a<=0)throw new E(b.INVALID_PAYMENT_CONFIG,"Invalid payment amount.");try{if(!w.G.getProvider(e))throw new E(b.GENERIC_PAYMENT_ERROR,"No Solana provider available.");const n=await l.x.sendTransaction({chainNamespace:m.o.CHAIN.SOLANA,to:t.recipient,value:a,tokenMint:t.tokenMint});if(!n)throw new E(b.GENERIC_PAYMENT_ERROR,"Transaction failed.");return n}catch(e){if(e instanceof E)throw e;throw new E(b.GENERIC_PAYMENT_ERROR,`Solana payment failed: ${e}`)}}(n,{recipient:_.recipient,amount:_.amount,fromAddress:a,tokenMint:"native"===_.paymentAsset.asset?void 0:_.paymentAsset.asset}),_.currentPayment.status="SUCCESS";break;default:throw new E(b.INVALID_CHAIN_NAMESPACE)}}catch(e){_.error=e instanceof E?e.message:v.GENERIC_PAYMENT_ERROR,_.currentPayment.status="FAILED",d.P.showError(_.error)}finally{_.isPaymentInProgress=!1}},getExchangeById:e=>_.exchanges.find(t=>t.id===e),validatePayConfig(e){const{paymentAsset:t,recipient:a,amount:n}=e;if(!t)throw new E(b.INVALID_PAYMENT_CONFIG);if(!a)throw new E(b.INVALID_RECIPIENT);if(!t.asset)throw new E(b.INVALID_ASSET);if(null==n||n<=0)throw new E(b.INVALID_AMOUNT)},handlePayWithWallet(){const e=o.W.getActiveCaipAddress();if(!e)return void f.I.push("Connect");const{chainId:t,address:a}=y.C.parseCaipAddress(e),n=o.W.state.activeChain;a&&t&&n?this.handlePayment():f.I.push("Connect")},async handlePayWithExchange(e){try{_.currentPayment={type:"exchange",exchangeId:e};const{network:t,asset:a}=_.paymentAsset,n={network:t,asset:a,amount:_.amount,recipient:_.recipient},i=await this.getPayUrl(e,n);if(!i)throw new E(b.UNABLE_TO_INITIATE_PAYMENT);return _.currentPayment.sessionId=i.sessionId,_.currentPayment.status="IN_PROGRESS",_.currentPayment.exchangeId=e,this.initiatePayment(),{url:i.url,openInNewTab:_.openInNewTab}}catch(e){return _.error=e instanceof E?e.message:v.GENERIC_PAYMENT_ERROR,_.isPaymentInProgress=!1,d.P.showError(_.error),null}},async getBuyStatus(e,t){try{const a=await async function(e){return(await A("reown_getExchangeBuyStatus",e)).result}({sessionId:t,exchangeId:e});return"SUCCESS"!==a.status&&"FAILED"!==a.status||g.E.sendEvent({type:"track",event:"SUCCESS"===a.status?"PAY_SUCCESS":"PAY_ERROR",properties:{message:"FAILED"===a.status?c.w.parseError(_.error):void 0,source:"pay",paymentId:_.paymentId||T,configuration:{network:_.paymentAsset.network,asset:_.paymentAsset.asset,recipient:_.recipient,amount:_.amount},currentPayment:{type:"exchange",exchangeId:_.currentPayment?.exchangeId,sessionId:_.currentPayment?.sessionId,result:a.txHash}}}),a}catch(e){throw new E(b.UNABLE_TO_GET_BUY_STATUS)}},async updateBuyStatus(e,t){try{const a=await this.getBuyStatus(e,t);_.currentPayment&&(_.currentPayment.status=a.status,_.currentPayment.result=a.txHash),"SUCCESS"!==a.status&&"FAILED"!==a.status||(_.isPaymentInProgress=!1)}catch(e){throw new E(b.UNABLE_TO_GET_BUY_STATUS)}},initiatePayment(){_.isPaymentInProgress=!0,_.paymentId=crypto.randomUUID()},initializeAnalytics(){_.analyticsSet||(_.analyticsSet=!0,this.subscribeKey("isPaymentInProgress",e=>{if(_.currentPayment?.status&&"UNKNOWN"!==_.currentPayment.status){const e={IN_PROGRESS:"PAY_INITIATED",SUCCESS:"PAY_SUCCESS",FAILED:"PAY_ERROR"}[_.currentPayment.status];g.E.sendEvent({type:"track",event:e,properties:{message:"FAILED"===_.currentPayment.status?c.w.parseError(_.error):void 0,source:"pay",paymentId:_.paymentId||T,configuration:{network:_.paymentAsset.network,asset:_.paymentAsset.asset,recipient:_.recipient,amount:_.amount},currentPayment:{type:_.currentPayment.type,exchangeId:_.currentPayment.exchangeId,sessionId:_.currentPayment.sessionId,result:_.currentPayment.result}}})}}))}},$=n.AH`
  wui-separator {
    margin: var(--apkt-spacing-3) calc(var(--apkt-spacing-3) * -1) var(--apkt-spacing-2)
      calc(var(--apkt-spacing-3) * -1);
    width: calc(100% + var(--apkt-spacing-3) * 2);
  }

  .token-display {
    padding: var(--apkt-spacing-3) var(--apkt-spacing-3);
    border-radius: var(--apkt-borderRadius-5);
    background-color: var(--apkt-tokens-theme-backgroundPrimary);
    margin-top: var(--apkt-spacing-3);
    margin-bottom: var(--apkt-spacing-3);
  }

  .token-display wui-text {
    text-transform: none;
  }

  wui-loading-spinner {
    padding: var(--apkt-spacing-2);
  }
`;var D=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let U=class extends n.WF{constructor(){super(),this.unsubscribe=[],this.amount="",this.tokenSymbol="",this.networkName="",this.exchanges=R.state.exchanges,this.isLoading=R.state.isLoading,this.loadingExchangeId=null,this.connectedWalletInfo=o.W.getAccountData()?.connectedWalletInfo,this.initializePaymentDetails(),this.unsubscribe.push(R.subscribeKey("exchanges",e=>this.exchanges=e)),this.unsubscribe.push(R.subscribeKey("isLoading",e=>this.isLoading=e)),this.unsubscribe.push(o.W.subscribeChainProp("accountState",e=>{this.connectedWalletInfo=e?.connectedWalletInfo})),R.fetchExchanges()}get isWalletConnected(){const e=o.W.getAccountData();return"connected"===e?.status}render(){return n.qy`
      <wui-flex flexDirection="column">
        <wui-flex flexDirection="column" .padding=${["0","4","4","4"]} gap="3">
          ${this.renderPaymentHeader()}

          <wui-flex flexDirection="column" gap="3">
            ${this.renderPayWithWallet()} ${this.renderExchangeOptions()}
          </wui-flex>
        </wui-flex>
      </wui-flex>
    `}initializePaymentDetails(){const e=R.getPaymentAsset();this.networkName=e.network,this.tokenSymbol=e.metadata.symbol,this.amount=R.state.amount.toString()}renderPayWithWallet(){return function(e){const{chainNamespace:t}=y.C.parseCaipNetworkId(e);return P.includes(t)}(this.networkName)?n.qy`<wui-flex flexDirection="column" gap="3">
        ${this.isWalletConnected?this.renderConnectedView():this.renderDisconnectedView()}
      </wui-flex>
      <wui-separator text="or"></wui-separator>`:n.qy``}renderPaymentHeader(){let e=this.networkName;if(this.networkName){const t=o.W.getAllRequestedCaipNetworks().find(e=>e.caipNetworkId===this.networkName);t&&(e=t.name)}return n.qy`
      <wui-flex flexDirection="column" alignItems="center">
        <wui-flex alignItems="center" gap="2">
          <wui-text variant="h1-regular" color="primary">${this.amount||"0.0000"}</wui-text>
          <wui-flex class="token-display" alignItems="center" gap="1">
            <wui-text variant="md-medium" color="primary">
              ${this.tokenSymbol||"Unknown Asset"}
            </wui-text>
            ${e?n.qy`
                  <wui-text variant="sm-medium" color="secondary">
                    on ${e}
                  </wui-text>
                `:""}
          </wui-flex>
        </wui-flex>
      </wui-flex>
    `}renderConnectedView(){const e=this.connectedWalletInfo?.name||"connected wallet";return n.qy`
      <wui-list-item
        @click=${this.onWalletPayment}
        ?chevron=${!0}
        ?fullSize=${!0}
        ?rounded=${!0}
        data-testid="wallet-payment-option"
        imageSrc=${(0,r.J)(this.connectedWalletInfo?.icon)}
      >
        <wui-text variant="lg-regular" color="primary">Pay with ${e}</wui-text>
      </wui-list-item>

      <wui-list-item
        icon="power"
        ?rounded=${!0}
        iconColor="error"
        @click=${this.onDisconnect}
        data-testid="disconnect-button"
        ?chevron=${!1}
      >
        <wui-text variant="lg-regular" color="secondary">Disconnect</wui-text>
      </wui-list-item>
    `}renderDisconnectedView(){return n.qy`<wui-list-item
      variant="icon"
      iconVariant="overlay"
      icon="wallet"
      ?rounded=${!0}
      @click=${this.onWalletPayment}
      ?chevron=${!0}
      data-testid="wallet-payment-option"
    >
      <wui-text variant="lg-regular" color="primary">Pay from wallet</wui-text>
    </wui-list-item>`}renderExchangeOptions(){return this.isLoading?n.qy`<wui-flex justifyContent="center" alignItems="center">
        <wui-spinner size="md"></wui-spinner>
      </wui-flex>`:0===this.exchanges.length?n.qy`<wui-flex justifyContent="center" alignItems="center">
        <wui-text variant="md-medium" color="primary">No exchanges available</wui-text>
      </wui-flex>`:this.exchanges.map(e=>n.qy`
        <wui-list-item
          @click=${()=>this.onExchangePayment(e.id)}
          data-testid="exchange-option-${e.id}"
          ?chevron=${!0}
          ?disabled=${null!==this.loadingExchangeId}
          ?loading=${this.loadingExchangeId===e.id}
          imageSrc=${(0,r.J)(e.imageUrl)}
        >
          <wui-flex alignItems="center" gap="3">
            <wui-text flexGrow="1" variant="md-medium" color="primary"
              >Pay with ${e.name} <wui-spinner size="sm" color="secondary"></wui-spinner
            ></wui-text>
          </wui-flex>
        </wui-list-item>
      `)}onWalletPayment(){R.handlePayWithWallet()}async onExchangePayment(e){try{this.loadingExchangeId=e;const t=await R.handlePayWithExchange(e);t&&(await s.W.open({view:"PayLoading"}),c.w.openHref(t.url,t.openInNewTab?"_blank":"_self"))}catch(e){console.error("Failed to pay with exchange",e),d.P.showError("Failed to pay with exchange")}finally{this.loadingExchangeId=null}}async onDisconnect(e){e.stopPropagation();try{await l.x.disconnect()}catch{console.error("Failed to disconnect"),d.P.showError("Failed to disconnect")}}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}};U.styles=$,D([(0,i.wk)()],U.prototype,"amount",void 0),D([(0,i.wk)()],U.prototype,"tokenSymbol",void 0),D([(0,i.wk)()],U.prototype,"networkName",void 0),D([(0,i.wk)()],U.prototype,"exchanges",void 0),D([(0,i.wk)()],U.prototype,"isLoading",void 0),D([(0,i.wk)()],U.prototype,"loadingExchangeId",void 0),D([(0,i.wk)()],U.prototype,"connectedWalletInfo",void 0),U=D([(0,u.EM)("w3m-pay-view")],U);var O=a(68996),M=a(36010),L=a(27601);a(92983);const z=n.AH`
  :host {
    display: block;
    height: 100%;
    width: 100%;
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-thumbnail {
    position: absolute;
  }
`;var W=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let G=class extends n.WF{constructor(){super(),this.loadingMessage="",this.subMessage="",this.paymentState="in-progress",this.paymentState=R.state.isPaymentInProgress?"in-progress":"completed",this.updateMessages(),this.setupSubscription(),this.setupExchangeSubscription()}disconnectedCallback(){clearInterval(this.exchangeSubscription)}render(){return n.qy`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["7","5","5","5"]}
        gap="9"
      >
        <wui-flex justifyContent="center" alignItems="center"> ${this.getStateIcon()} </wui-flex>
        <wui-flex flexDirection="column" alignItems="center" gap="2">
          <wui-text align="center" variant="lg-medium" color="primary">
            ${this.loadingMessage}
          </wui-text>
          <wui-text align="center" variant="lg-regular" color="secondary">
            ${this.subMessage}
          </wui-text>
        </wui-flex>
      </wui-flex>
    `}updateMessages(){switch(this.paymentState){case"completed":this.loadingMessage="Payment completed",this.subMessage="Your transaction has been successfully processed";break;case"error":this.loadingMessage="Payment failed",this.subMessage="There was an error processing your transaction";break;default:"exchange"===R.state.currentPayment?.type?(this.loadingMessage="Payment initiated",this.subMessage="Please complete the payment on the exchange"):(this.loadingMessage="Awaiting payment confirmation",this.subMessage="Please confirm the payment transaction in your wallet")}}getStateIcon(){switch(this.paymentState){case"completed":return this.successTemplate();case"error":return this.errorTemplate();default:return this.loaderTemplate()}}setupExchangeSubscription(){"exchange"===R.state.currentPayment?.type&&(this.exchangeSubscription=setInterval(async()=>{const e=R.state.currentPayment?.exchangeId,t=R.state.currentPayment?.sessionId;e&&t&&(await R.updateBuyStatus(e,t),"SUCCESS"===R.state.currentPayment?.status&&clearInterval(this.exchangeSubscription))},4e3))}setupSubscription(){R.subscribeKey("isPaymentInProgress",e=>{e||"in-progress"!==this.paymentState||(R.state.error||!R.state.currentPayment?.result?this.paymentState="error":this.paymentState="completed",this.updateMessages(),setTimeout(()=>{"disconnected"!==l.x.state.status&&s.W.close()},3e3))}),R.subscribeKey("error",e=>{e&&"in-progress"===this.paymentState&&(this.paymentState="error",this.updateMessages())})}loaderTemplate(){const e=O.W.state.themeVariables["--w3m-border-radius-master"],t=e?parseInt(e.replace("px",""),10):4,a=this.getPaymentIcon();return n.qy`
      <wui-flex justifyContent="center" alignItems="center" style="position: relative;">
        ${a?n.qy`<wui-wallet-image size="lg" imageSrc=${a}></wui-wallet-image>`:null}
        <wui-loading-thumbnail radius=${9*t}></wui-loading-thumbnail>
      </wui-flex>
    `}getPaymentIcon(){const e=R.state.currentPayment;if(e){if("exchange"===e.type){const t=e.exchangeId;if(t){const e=R.getExchangeById(t);return e?.imageUrl}}if("wallet"===e.type){const e=o.W.getAccountData()?.connectedWalletInfo?.icon;if(e)return e;const t=o.W.state.activeChain;if(!t)return;const a=M.a.getConnectorId(t);if(!a)return;const n=M.a.getConnectorById(a);if(!n)return;return L.$.getConnectorImage(n)}}}successTemplate(){return n.qy`<wui-icon size="xl" color="success" name="checkmark"></wui-icon>`}errorTemplate(){return n.qy`<wui-icon size="xl" color="error" name="close"></wui-icon>`}};G.styles=z,W([(0,i.wk)()],G.prototype,"loadingMessage",void 0),W([(0,i.wk)()],G.prototype,"subMessage",void 0),W([(0,i.wk)()],G.prototype,"paymentState",void 0),G=W([(0,u.EM)("w3m-pay-loading-view")],G);const B=3e5;async function Y(e){return R.handleOpenPay(e)}async function V(e,t=B){if(t<=0)throw new E(b.INVALID_PAYMENT_CONFIG,"Timeout must be greater than 0");try{await Y(e)}catch(e){if(e instanceof E)throw e;throw new E(b.UNABLE_TO_INITIATE_PAYMENT,e.message)}return new Promise((e,a)=>{let n=!1;const i=setTimeout(()=>{n||(n=!0,d(),a(new E(b.GENERIC_PAYMENT_ERROR,"Payment timeout")))},t);function r(){if(n)return;const t=R.state.currentPayment,a=R.state.error,r=R.state.isPaymentInProgress;return"SUCCESS"===t?.status?(n=!0,d(),clearTimeout(i),void e({success:!0,result:t.result})):"FAILED"===t?.status?(n=!0,d(),clearTimeout(i),void e({success:!1,error:a||"Payment failed"})):void(!a||r||t||(n=!0,d(),clearTimeout(i),e({success:!1,error:a})))}const o=Z("currentPayment",r),s=Z("error",r),c=Z("isPaymentInProgress",r),d=(l=[o,s,c],()=>{l.forEach(e=>{try{e()}catch{}})});var l;r()})}function q(){return R.getExchanges()}function F(){return R.state.currentPayment?.result}function j(){return R.state.error}function H(){return R.state.isPaymentInProgress}function Z(e,t){return R.subscribeKey(e,t)}const K={network:"eip155:8453",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},J={network:"eip155:8453",asset:"0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},X={network:"eip155:84532",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},Q={network:"eip155:1",asset:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},ee={network:"eip155:10",asset:"0x0b2c639c533813f4aa9d7837caf62653d097ff85",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},te={network:"eip155:42161",asset:"0xaf88d065e77c8cC2239327C5EDb3A432268e5831",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},ae={network:"eip155:137",asset:"0x3c499c542cef5e3811e1192ce70d8cc03d5c3359",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},ne={network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},ie={network:"eip155:1",asset:"0xdAC17F958D2ee523a2206206994597C13D831ec7",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},re={network:"eip155:10",asset:"0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},oe={network:"eip155:42161",asset:"0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},se={network:"eip155:137",asset:"0xc2132d05d31c914a87c6611c10748aeb04b58e8f",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},ce={network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},de={network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"native",metadata:{name:"Solana",symbol:"SOL",decimals:9}}},84293:(e,t,a)=>{var n=a(12618),i=a(25707),r=a(60031),o=(a(14991),a(26109)),s=a(43494);const c=a(67569).AH`
  :host {
    position: relative;
  }

  button {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: transparent;
    padding: ${({spacing:e})=>e[1]};
  }

  /* -- Colors --------------------------------------------------- */
  button[data-type='accent'] wui-icon {
    color: ${({tokens:e})=>e.core.iconAccentPrimary};
  }

  button[data-type='neutral'][data-variant='primary'] wui-icon {
    color: ${({tokens:e})=>e.theme.iconInverse};
  }

  button[data-type='neutral'][data-variant='secondary'] wui-icon {
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  button[data-type='success'] wui-icon {
    color: ${({tokens:e})=>e.core.iconSuccess};
  }

  button[data-type='error'] wui-icon {
    color: ${({tokens:e})=>e.core.iconError};
  }

  /* -- Sizes --------------------------------------------------- */
  button[data-size='xs'] {
    width: 16px;
    height: 16px;

    border-radius: ${({borderRadius:e})=>e[1]};
  }

  button[data-size='sm'] {
    width: 20px;
    height: 20px;
    border-radius: ${({borderRadius:e})=>e[1]};
  }

  button[data-size='md'] {
    width: 24px;
    height: 24px;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  button[data-size='lg'] {
    width: 28px;
    height: 28px;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  button[data-size='xs'] wui-icon {
    width: 8px;
    height: 8px;
  }

  button[data-size='sm'] wui-icon {
    width: 12px;
    height: 12px;
  }

  button[data-size='md'] wui-icon {
    width: 16px;
    height: 16px;
  }

  button[data-size='lg'] wui-icon {
    width: 20px;
    height: 20px;
  }

  /* -- Hover --------------------------------------------------- */
  @media (hover: hover) {
    button[data-type='accent']:hover:enabled {
      background-color: ${({tokens:e})=>e.core.foregroundAccent010};
    }

    button[data-variant='primary'][data-type='neutral']:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }

    button[data-variant='secondary'][data-type='neutral']:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }

    button[data-type='success']:hover:enabled {
      background-color: ${({tokens:e})=>e.core.backgroundSuccess};
    }

    button[data-type='error']:hover:enabled {
      background-color: ${({tokens:e})=>e.core.backgroundError};
    }
  }

  /* -- Focus --------------------------------------------------- */
  button:focus-visible {
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent020};
  }

  /* -- Properties --------------------------------------------------- */
  button[data-full-width='true'] {
    width: 100%;
  }

  :host([fullWidth]) {
    width: 100%;
  }

  button[disabled] {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var d=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let l=class extends n.WF{constructor(){super(...arguments),this.icon="card",this.variant="primary",this.type="accent",this.size="md",this.iconSize=void 0,this.fullWidth=!1,this.disabled=!1}render(){return n.qy`<button
      data-variant=${this.variant}
      data-type=${this.type}
      data-size=${this.size}
      data-full-width=${this.fullWidth}
      ?disabled=${this.disabled}
    >
      <wui-icon color="inherit" name=${this.icon} size=${(0,r.J)(this.iconSize)}></wui-icon>
    </button>`}};l.styles=[o.W5,o.fD,c],d([(0,i.MZ)()],l.prototype,"icon",void 0),d([(0,i.MZ)()],l.prototype,"variant",void 0),d([(0,i.MZ)()],l.prototype,"type",void 0),d([(0,i.MZ)()],l.prototype,"size",void 0),d([(0,i.MZ)()],l.prototype,"iconSize",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"fullWidth",void 0),d([(0,i.MZ)({type:Boolean})],l.prototype,"disabled",void 0),l=d([(0,s.E)("wui-icon-button")],l)},91383:(e,t,a)=>{var n=a(12618),i=a(25707),r=(a(14991),a(36887),a(26109)),o=a(43494);a(12851);const s=a(67569).AH`
  :host {
    position: relative;
    background-color: ${({tokens:e})=>e.theme.foregroundTertiary};
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host([data-image='true']) {
    background-color: transparent;
  }

  :host > wui-flex {
    overflow: hidden;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host([data-size='sm']) {
    width: 32px;
    height: 32px;
  }

  :host([data-size='md']) {
    width: 40px;
    height: 40px;
  }

  :host([data-size='lg']) {
    width: 56px;
    height: 56px;
  }

  :host([name='Extension'])::after {
    border: 1px solid ${({colors:e})=>e.accent010};
  }

  :host([data-wallet-icon='allWallets'])::after {
    border: 1px solid ${({colors:e})=>e.accent010};
  }

  wui-icon[data-parent-size='inherit'] {
    width: 75%;
    height: 75%;
    align-items: center;
  }

  wui-icon[data-parent-size='sm'] {
    width: 32px;
    height: 32px;
  }

  wui-icon[data-parent-size='md'] {
    width: 40px;
    height: 40px;
  }

  :host > wui-icon-box {
    position: absolute;
    overflow: hidden;
    right: -1px;
    bottom: -2px;
    z-index: 1;
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
    padding: 1px;
  }
`;var c=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let d=class extends n.WF{constructor(){super(...arguments),this.size="md",this.name="",this.installed=!1,this.badgeSize="xs"}render(){let e="1";return"lg"===this.size?e="4":"md"===this.size?e="2":"sm"===this.size&&(e="1"),this.style.cssText=`\n       --local-border-radius: var(--apkt-borderRadius-${e});\n   `,this.dataset.size=this.size,this.imageSrc&&(this.dataset.image="true"),this.walletIcon&&(this.dataset.walletIcon=this.walletIcon),n.qy`
      <wui-flex justifyContent="center" alignItems="center"> ${this.templateVisual()} </wui-flex>
    `}templateVisual(){return this.imageSrc?n.qy`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:this.walletIcon?n.qy`<wui-icon size="md" color="default" name=${this.walletIcon}></wui-icon>`:n.qy`<wui-icon
      data-parent-size=${this.size}
      size="inherit"
      color="inherit"
      name="wallet"
    ></wui-icon>`}};d.styles=[r.W5,s],c([(0,i.MZ)()],d.prototype,"size",void 0),c([(0,i.MZ)()],d.prototype,"name",void 0),c([(0,i.MZ)()],d.prototype,"imageSrc",void 0),c([(0,i.MZ)()],d.prototype,"walletIcon",void 0),c([(0,i.MZ)({type:Boolean})],d.prototype,"installed",void 0),c([(0,i.MZ)()],d.prototype,"badgeSize",void 0),d=c([(0,o.E)("wui-wallet-image")],d)},92983:(e,t,a)=>{var n=a(12618),i=a(25707),r=a(26109),o=a(43494);const s=a(67569).AH`
  :host {
    display: block;
    width: 100px;
    height: 100px;
  }

  svg {
    width: 100px;
    height: 100px;
  }

  rect {
    fill: none;
    stroke: ${e=>e.colors.accent100};
    stroke-width: 3px;
    stroke-linecap: round;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`;var c=function(e,t,a,n){var i,r=arguments.length,o=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,a):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)o=Reflect.decorate(e,t,a,n);else for(var s=e.length-1;s>=0;s--)(i=e[s])&&(o=(r<3?i(o):r>3?i(t,a,o):i(t,a))||o);return r>3&&o&&Object.defineProperty(t,a,o),o};let d=class extends n.WF{constructor(){super(...arguments),this.radius=36}render(){return this.svgLoaderTemplate()}svgLoaderTemplate(){const e=this.radius>50?50:this.radius,t=36-e,a=116+t,i=245+t,r=360+1.75*t;return n.qy`
      <svg viewBox="0 0 110 110" width="110" height="110">
        <rect
          x="2"
          y="2"
          width="106"
          height="106"
          rx=${e}
          stroke-dasharray="${a} ${i}"
          stroke-dashoffset=${r}
        />
      </svg>
    `}};d.styles=[r.W5,s],c([(0,i.MZ)({type:Number})],d.prototype,"radius",void 0),d=c([(0,o.E)("wui-loading-thumbnail")],d)},93373:(e,t,a)=>{a(20880)},93516:(e,t,a)=>{a(36887)}}]);
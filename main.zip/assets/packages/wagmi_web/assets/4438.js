"use strict";(self.webpackChunk=self.webpackChunk||[]).push([[4438],{64438:(t,e,r)=>{r.r(e),r.d(e,{PhArrowLeft:()=>c}),r(94687);var l=r(76058),a=r(15375),o=r(3588),i=r(31409),s=r(11893),h=Object.defineProperty,p=Object.getOwnPropertyDescriptor,n=(t,e,r,l)=>{for(var a,o=l>1?void 0:l?p(e,r):e,i=t.length-1;i>=0;i--)(a=t[i])&&(o=(l?a(e,r,o):a(o))||o);return l&&o&&h(e,r,o),o};let c=class extends a.WF{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return l.qy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",l.JW`<path d="M220,128a4,4,0,0,1-4,4H49.66l65.17,65.17a4,4,0,0,1-5.66,5.66l-72-72a4,4,0,0,1,0-5.66l72-72a4,4,0,0,1,5.66,5.66L49.66,124H216A4,4,0,0,1,220,128Z"/>`],["light",l.JW`<path d="M222,128a6,6,0,0,1-6,6H54.49l61.75,61.76a6,6,0,1,1-8.48,8.48l-72-72a6,6,0,0,1,0-8.48l72-72a6,6,0,0,1,8.48,8.48L54.49,122H216A6,6,0,0,1,222,128Z"/>`],["regular",l.JW`<path d="M224,128a8,8,0,0,1-8,8H59.31l58.35,58.34a8,8,0,0,1-11.32,11.32l-72-72a8,8,0,0,1,0-11.32l72-72a8,8,0,0,1,11.32,11.32L59.31,120H216A8,8,0,0,1,224,128Z"/>`],["bold",l.JW`<path d="M228,128a12,12,0,0,1-12,12H69l51.52,51.51a12,12,0,0,1-17,17l-72-72a12,12,0,0,1,0-17l72-72a12,12,0,0,1,17,17L69,116H216A12,12,0,0,1,228,128Z"/>`],["fill",l.JW`<path d="M224,128a8,8,0,0,1-8,8H120v64a8,8,0,0,1-13.66,5.66l-72-72a8,8,0,0,1,0-11.32l72-72A8,8,0,0,1,120,56v64h96A8,8,0,0,1,224,128Z"/>`],["duotone",l.JW`<path d="M112,56V200L40,128Z" opacity="0.2"/><path d="M216,120H120V56a8,8,0,0,0-13.66-5.66l-72,72a8,8,0,0,0,0,11.32l72,72A8,8,0,0,0,120,200V136h96a8,8,0,0,0,0-16ZM104,180.69,51.31,128,104,75.31Z"/>`]]),c.styles=s.AH`
    :host {
      display: contents;
    }
  `,n([(0,i.M)({type:String,reflect:!0})],c.prototype,"size",2),n([(0,i.M)({type:String,reflect:!0})],c.prototype,"weight",2),n([(0,i.M)({type:String,reflect:!0})],c.prototype,"color",2),n([(0,i.M)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=n([(0,o.E)("ph-arrow-left")],c)}}]);
'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"assets/AssetManifest.bin": "c56aebfa8ae2a276febe02509f75c28d",
"assets/AssetManifest.bin.json": "2b178ad8423db5b74895305076f16c5f",
"assets/assets/gif/splash.gif": "8c8f8a0c8159f0b99ec0ea851b794300",
"assets/assets/json/loading2.json": "8bb2cd2f1870faf566bb0444cb893e51",
"assets/assets/png/canada.png": "0e5f609c0aa0fdfe8fae22401b63ebfa",
"assets/assets/png/germany.png": "4a3ac99b9f4166fce3e968b9636cb1fd",
"assets/assets/png/home_off.png": "af9a242905db7b17ec0dc85895db9f50",
"assets/assets/png/home_on.png": "9596dd1a6727911a2867992bb30cef63",
"assets/assets/png/person_off.png": "aa60daa1f0b8617ccd343faf54ab5978",
"assets/assets/png/person_on.png": "450f6ba34d4986e8c71231a62b4d4d07",
"assets/assets/png/plot.png": "4557ae43eb7ad20bffb357891c9f036a",
"assets/assets/png/power_red_btn.png": "cadffebf041155b1ee37cfc1671f34f2",
"assets/assets/png/Profile%2520Avatar.png": "fd8abbb16730ae7f585ff71ea84bcf11",
"assets/assets/png/sheet_off.png": "a90516b877bc42466d1a4dc42927aefa",
"assets/assets/png/sheet_on.png": "53d1681fbc2c14f82e0e5fbe8239e8b3",
"assets/assets/png/tick.png": "bc087d580d6c2b8dc6c93802d37ac163",
"assets/assets/png/united%2520states.png": "b3c8d2911e121932bc0bc1781a34845a",
"assets/assets/png/world.png": "9dbe4211fe744937d5ac5e52c2a18e4c",
"assets/assets/png/world2.png": "f43a7aeca3b6af4be8c4c13721544f44",
"assets/assets/svg/arrow-bottom-large.svg": "78ac90024eb0d467cf96d855f53b378b",
"assets/assets/svg/arrow-top-large.svg": "911d1b54df823bc8e8e2f50aae0659e7",
"assets/assets/svg/balad_vpn.svg": "7c9f0b24aa8e3452f6ea08700d575ac9",
"assets/assets/svg/balad_vpn_text.svg": "eeb632d09094247e47b8a9e5636d0645",
"assets/assets/svg/balad_vpn_text_white.svg": "f8e70fbc38831ada5039deb4c85a1022",
"assets/assets/svg/download_speed.svg": "5fd86654ed3d865d9968aefc71975af5",
"assets/assets/svg/power_green_btn.svg": "109bd1252bd57d789b82d90dc1d1ff4d",
"assets/assets/svg/power_red_btn.svg": "14a7e60c0a7aa191b67690e288c22b54",
"assets/assets/svg/tesr_btn.svg": "99f8f5e6f330d954f45ebc1352eb887e",
"assets/assets/svg/upload_speed.svg": "fa5f684ef3d22aaa85c14d1f1acfe261",
"assets/assets/svg/world.svg": "3da124c6102ff680331d8db32808be03",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/fonts/MaterialIcons-Regular.otf": "c0ad29d56cfe3890223c02da3c6e0448",
"assets/NOTICES": "e23238f545f03eaeb60a88a5e41d0654",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/packages/wagmi_web/assets/1349.js": "d7bad00ec144b72fc06765e8ff97133f",
"assets/packages/wagmi_web/assets/1611.js": "f021b3a4c4c5010e120d4c17b1ca3852",
"assets/packages/wagmi_web/assets/1634.js": "3771eb5687441d3e0e8c5f2eb6de029f",
"assets/packages/wagmi_web/assets/1884.js": "7862889832b0e6a744897e8468aec84d",
"assets/packages/wagmi_web/assets/1992.js": "b29064bfc4550a36d57d9308e90208be",
"assets/packages/wagmi_web/assets/2099.js": "1ae1a385fd036353406904fb48d1f0c2",
"assets/packages/wagmi_web/assets/2099.js.LICENSE.txt": "6293c204f4d048d5b238a05e47b362f6",
"assets/packages/wagmi_web/assets/2143.js": "9f58aef4bbf857f383a515a9915bf3b1",
"assets/packages/wagmi_web/assets/2272.js": "ad8f2d63322507604eb73b8f98e45175",
"assets/packages/wagmi_web/assets/2715.js": "5e9c1f11f2bf94fb75f237cdb4249655",
"assets/packages/wagmi_web/assets/2798.js": "4ae03b88279aebd01edaed7fd7d0c0bd",
"assets/packages/wagmi_web/assets/2799.js": "a0ec7761792d756d6f53c5d5f19f612e",
"assets/packages/wagmi_web/assets/2862.js": "564c9c765dced86048907a199ca28afa",
"assets/packages/wagmi_web/assets/2862.js.LICENSE.txt": "c11bb1d2d38962df13da3ce4dec84c31",
"assets/packages/wagmi_web/assets/3066.js": "2cc006e0a9a511b10ecec8b15edb1fea",
"assets/packages/wagmi_web/assets/312.js": "5c13b7115756cce68899bbc917f1c6e5",
"assets/packages/wagmi_web/assets/3203.js": "8fccbcdc3df46becdd20984f4cbd7b82",
"assets/packages/wagmi_web/assets/3302.js": "7034991b221ef66eec1615176b875f47",
"assets/packages/wagmi_web/assets/3302.js.LICENSE.txt": "2115b09bd8a60276ff686cb19d9e389d",
"assets/packages/wagmi_web/assets/3317.js": "a1630695815a32656e354eb03ef8ef50",
"assets/packages/wagmi_web/assets/336.js": "3ba255eb92b4b7f97740dd0b16f72ac2",
"assets/packages/wagmi_web/assets/3456.js": "dd0d5b30d4c701e10f4e5ce007b74aed",
"assets/packages/wagmi_web/assets/3462.js": "d3cdde921f6903314b3478a4c4f42839",
"assets/packages/wagmi_web/assets/3543.js": "d1c3a1b152431af128848faba9ec9dc8",
"assets/packages/wagmi_web/assets/3617.js": "7e87422073e3dc81a771e3a8fff72ebb",
"assets/packages/wagmi_web/assets/3638.js": "dcce5887e3dba7bcde3883263f27652e",
"assets/packages/wagmi_web/assets/3758.js": "e3a63e13823e0bb17be336e8806eee15",
"assets/packages/wagmi_web/assets/3851.js": "e17221c19c8487fdc618b5514cf09919",
"assets/packages/wagmi_web/assets/3864.js": "e545e8ac205fda6cccc2b77a0abcce81",
"assets/packages/wagmi_web/assets/3864.js.LICENSE.txt": "c11bb1d2d38962df13da3ce4dec84c31",
"assets/packages/wagmi_web/assets/4042.js": "15afea60b96b489f8f0a77d76249d6b0",
"assets/packages/wagmi_web/assets/4217.js": "3804b3246b0739eb4609c6168ffc0716",
"assets/packages/wagmi_web/assets/4438.js": "207f255907a297873b64de54e50a5bfe",
"assets/packages/wagmi_web/assets/4771.js": "0e16c15caa2c98d18aef4c6ec606e466",
"assets/packages/wagmi_web/assets/485.js": "63b2f695a71b87042b696129122d95bf",
"assets/packages/wagmi_web/assets/4899.js": "4e98bbe96a3418abbe49a753a4ec481a",
"assets/packages/wagmi_web/assets/5049.js": "60ab60d514a80af5da71ca20676a6dde",
"assets/packages/wagmi_web/assets/5195.js": "059047b2bf8fafa33898317c0ccb7727",
"assets/packages/wagmi_web/assets/5264.js": "ac28a7b6e08fde585d92dbf4d907cd1a",
"assets/packages/wagmi_web/assets/531.js": "235f8d757c6cb902f76a9113807c68a5",
"assets/packages/wagmi_web/assets/5803.js": "1ef6cf92c839b368ec4d1add37840e86",
"assets/packages/wagmi_web/assets/5845.js": "55fe9de742298cfd96b8dd151e8cf015",
"assets/packages/wagmi_web/assets/5882.js": "aa8275b1beaefdc9a26408fdac49ccbd",
"assets/packages/wagmi_web/assets/6056.js": "3240d2d5ae8bd5e4491198dc492213ff",
"assets/packages/wagmi_web/assets/6121.js": "57de95a419338a6cbf501ecdc9aab8bf",
"assets/packages/wagmi_web/assets/6121.js.LICENSE.txt": "2115b09bd8a60276ff686cb19d9e389d",
"assets/packages/wagmi_web/assets/6238.js": "9b582b3c116f8807744f133d6f091bab",
"assets/packages/wagmi_web/assets/626.js": "5a309667800be83d1561e0958612538e",
"assets/packages/wagmi_web/assets/6262.js": "df5f5eeab47a27dabbd83d64de9b0c23",
"assets/packages/wagmi_web/assets/6283.js": "2a3c5604d348da546afd5e352ff4815a",
"assets/packages/wagmi_web/assets/6311.js": "7188df97b5bcca42a4f6488fb7911ef2",
"assets/packages/wagmi_web/assets/6311.js.LICENSE.txt": "2115b09bd8a60276ff686cb19d9e389d",
"assets/packages/wagmi_web/assets/6378.js": "793b2ef0a55ddb993d29b24f52abfb4d",
"assets/packages/wagmi_web/assets/6378.js.LICENSE.txt": "2115b09bd8a60276ff686cb19d9e389d",
"assets/packages/wagmi_web/assets/6412.js": "8ffc783373608556a72ac00ed03c9146",
"assets/packages/wagmi_web/assets/6482.js": "06a2b77c6e1346b4744db4d833678b02",
"assets/packages/wagmi_web/assets/6526.js": "0ebcb4dc9ea219434b2b36e0bfa10dd4",
"assets/packages/wagmi_web/assets/654.js": "edd9fac6d87315ea80ee3f01ad84aae5",
"assets/packages/wagmi_web/assets/6570.js": "099506b861312d5f17d0882c7da335ee",
"assets/packages/wagmi_web/assets/6598.js": "2222734524f943ba914febc9b39a0062",
"assets/packages/wagmi_web/assets/6630.js": "a0afb3217de050670e463b7f3312f81f",
"assets/packages/wagmi_web/assets/6738.js": "51f3e46068d4561514b2d00e4359bac9",
"assets/packages/wagmi_web/assets/6903.js": "0afee2cfb693a9bffb1a27c068b45ec6",
"assets/packages/wagmi_web/assets/7040.js": "f4bb33a9bb657a9bb9e22fa6bf5e4dd0",
"assets/packages/wagmi_web/assets/7309.js": "3e366344db7c8ec83261914515573ff9",
"assets/packages/wagmi_web/assets/7309.js.LICENSE.txt": "6293c204f4d048d5b238a05e47b362f6",
"assets/packages/wagmi_web/assets/7410.js": "40a6395138afed2845960ae82a1ac14e",
"assets/packages/wagmi_web/assets/7410.js.LICENSE.txt": "c11bb1d2d38962df13da3ce4dec84c31",
"assets/packages/wagmi_web/assets/758.js": "cc8570cd20521223a8838c965b01a5aa",
"assets/packages/wagmi_web/assets/7726.js": "24d8b8825b29c551d510c9b0a0bc6bbd",
"assets/packages/wagmi_web/assets/7753.js": "26b1224953fc22e004d6470d4aed9319",
"assets/packages/wagmi_web/assets/7805.js": "f34673a6fe4b37c89f99931507bb5292",
"assets/packages/wagmi_web/assets/8058.js": "7e785326cfc05ce289406232fb9f07b8",
"assets/packages/wagmi_web/assets/809.js": "18ce969c8055e4962648adfffaf8907e",
"assets/packages/wagmi_web/assets/8109.js": "3bef4593832470fcfdf4a56c1e7d1f85",
"assets/packages/wagmi_web/assets/858.js": "984178a8b46063d3efc21e516159aa7b",
"assets/packages/wagmi_web/assets/8589.js": "dabe86ddd3e82352794bc46fd26ec87f",
"assets/packages/wagmi_web/assets/8664.js": "31a99289b9020370bfca6aff5eb919ee",
"assets/packages/wagmi_web/assets/8732.js": "02e4e853dd13ec11e1e1f4b319414287",
"assets/packages/wagmi_web/assets/8732.js.LICENSE.txt": "2115b09bd8a60276ff686cb19d9e389d",
"assets/packages/wagmi_web/assets/8920.js": "e17c8322f371709c47995f1de91cde19",
"assets/packages/wagmi_web/assets/9229.js": "e8175e9792454e0785db0007a96acd1b",
"assets/packages/wagmi_web/assets/9237.js": "5e93c073ec5b6bbb6e95e104cd0e1289",
"assets/packages/wagmi_web/assets/9296.js": "9a27c5e1de09e357c4ee552986d496b3",
"assets/packages/wagmi_web/assets/9571.js": "02a6dc10f9ca72a30dada1b5dca3f8db",
"assets/packages/wagmi_web/assets/9596.js": "1c8b03125af3953397a781901fa4e4c9",
"assets/packages/wagmi_web/assets/9596.js.LICENSE.txt": "d6e365ae17f39f0a72d2feb1e47ed40e",
"assets/packages/wagmi_web/assets/9657.js": "517f727c2206cc318a10280690281a16",
"assets/packages/wagmi_web/assets/9721.js": "7373761e93dddb721510754db5d39b68",
"assets/packages/wagmi_web/assets/9780.js": "a51e58069b24ccbfca4766996ba40ddc",
"assets/packages/wagmi_web/assets/9843.js": "13bd1708a9eaabad27e91eabeaaaf291",
"assets/packages/wagmi_web/assets/9990.js": "4738ed14ef5370af25091f6612b1b97c",
"assets/packages/wagmi_web/assets/9990.js.LICENSE.txt": "ddaef1761da9718367006e6a051e587c",
"assets/packages/wagmi_web/assets/main.js": "8e3e86bdd6bea3ce8ed4f8a515a1c974",
"assets/packages/wagmi_web/assets/main.js.LICENSE.txt": "d1ddba50369b97e86053829c987be639",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/shaders/stretch_effect.frag": "40d68efbbf360632f614c731219e95f0",
"canvaskit/canvaskit.js": "8331fe38e66b3a898c4f37648aaf7ee2",
"canvaskit/canvaskit.js.symbols": "a3c9f77715b642d0437d9c275caba91e",
"canvaskit/canvaskit.wasm": "9b6a7830bf26959b200594729d73538e",
"canvaskit/chromium/canvaskit.js": "a80c765aaa8af8645c9fb1aae53f9abf",
"canvaskit/chromium/canvaskit.js.symbols": "e2d09f0e434bc118bf67dae526737d07",
"canvaskit/chromium/canvaskit.wasm": "a726e3f75a84fcdf495a15817c63a35d",
"canvaskit/skwasm.js": "8060d46e9a4901ca9991edd3a26be4f0",
"canvaskit/skwasm.js.symbols": "3a4aadf4e8141f284bd524976b1d6bdc",
"canvaskit/skwasm.wasm": "7e5f3afdd3b0747a1fd4517cea239898",
"canvaskit/skwasm_heavy.js": "740d43a6b8240ef9e23eed8c48840da4",
"canvaskit/skwasm_heavy.js.symbols": "0755b4fb399918388d71b59ad390b055",
"canvaskit/skwasm_heavy.wasm": "b0be7910760d205ea4e011458df6ee01",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"flutter.js": "24bc71911b75b5f8135c949e27a2984e",
"flutter_bootstrap.js": "8968e289186fc103aa91805490a650ab",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "5ee0019a006b6cf1cb2ab019b27d3977",
"/": "5ee0019a006b6cf1cb2ab019b27d3977",
"main.dart.js": "372c56545745b66224a0d829294d18ec",
"manifest.json": "803305af4af8d0e55b7304909b5fe2a3",
"version.json": "74287285179aa086afc66b2cf16a0e1e"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    created_at: { type: Date, default: Date.now },
    last_buy: { type: Date, default: null },

    walletAddress: {
        type: String,
        required: true,
        unique: true
    },

    configLink: { type: String, default: "" },

    expired_at: {
        type: Date,
        required: true
    },

    volume_gb: { type: Number, default: 0 },

    transactionID: {
        type: String,
        default: ""
    }

});

module.exports = mongoose.model('User', userSchema);

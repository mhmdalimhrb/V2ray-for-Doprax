const mongoose = require('mongoose');
const User = require('../model/User');

/**
 * GET USER BY WALLET
 */
exports.getUserByWallet = async (req, res) => {
    try {
        const { walletAddress } = req.body;

        if (!walletAddress) {
            return res.status(400).json({ message: 'walletAddress is required' });
        }

        const user = await User.findOne({ walletAddress });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        return res.status(200).json({
            configLink: user.configLink,
            expired_at: user.expired_at,
            transactionID: user.transactionID
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};


/**
 * GET ACCOUNT DATA
 * create user if not exists (7 days trial)
 */
exports.getAccountData = async (req, res) => {
    try {
        const { walletAddress } = req.body;

        if (!walletAddress) {
            return res.status(400).json({ message: 'walletAddress is required' });
        }

        let user = await User.findOne({ walletAddress });

        if (!user) {
            const now = new Date();
            const expiredAt = new Date(now);
            expiredAt.setDate(now.getDate() + 7);

            user = await User.create({
                walletAddress,
                created_at: new Date(),
                last_buy: null,
                configLink: "",
                expired_at: expiredAt,
                transactionID: ""
            });
        }

        return res.status(200).json({
            expired_at: user.expired_at,
            configLink: user.configLink,
            transactionID: user.transactionID
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};


/**
 * SUBSCRIPTION UPDATED
 */
exports.subscriptionUpdated = async (req, res) => {
    try {
        const { walletAddress, expiredAt, transactionID } = req.body;

        if (!walletAddress || !expiredAt || !transactionID) {
            return res.status(400).json({
                message: 'walletAddress, expiredAt and transactionID are required'
            });
        }

        const user = await User.findOne({ walletAddress });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        user.expired_at = new Date(expiredAt);
        user.transactionID = transactionID;
        user.last_buy = new Date();

        await user.save();

        console.log('✅ Subscription updated | DB:', mongoose.connection.name);

        return res.status(200).json({
            message: 'Subscription updated successfully'
        });

    } catch (error) {
        console.error('❌ Error in subscriptionUpdated:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};


/**
 * GET ACCOUNT DATA FOR CONFIG APP
 */
exports.getAccountDataConfigApp = async (req, res) => {
    try {
        const { walletAddress } = req.body;

        if (!walletAddress) {
            return res.status(400).json({ message: 'walletAddress is required' });
        }

        let user = await User.findOne({ walletAddress });

        if (!user) {
            const now = new Date();
            const expiredAt = new Date(now);
            expiredAt.setDate(now.getDate() + 7);

            user = await User.create({
                walletAddress,
                created_at: new Date(),
                last_buy: null,
                configLink: "",
                expired_at: expiredAt,
                volume_gb: 0,
                transactionID: ""
            });
        }

        return res.status(200).json({
            expired_at: user.expired_at,
            configLink: user.configLink,
            volume_gb: user.volume_gb,
            transactionID: user.transactionID
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

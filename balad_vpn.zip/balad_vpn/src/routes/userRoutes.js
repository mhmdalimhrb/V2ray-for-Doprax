const express = require('express');
const router = express.Router();
const { getUserByWallet , getAccountData , subscriptionUpdated } = require('../controllers/userController');

router.post('/get-user', getUserByWallet);

router.post('/get-account-data', getAccountData);

router.post('/subscription-updated', subscriptionUpdated);

module.exports = router;    
